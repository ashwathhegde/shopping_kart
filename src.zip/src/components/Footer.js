import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import styles from './style.scss';
import Search from "./Search";
class Footer extends Component {
   
    render() {
        return (
          <footer>
            Copyright Ashwath Hegde
        </footer>
        )
        
        
}}

 
export default Footer;